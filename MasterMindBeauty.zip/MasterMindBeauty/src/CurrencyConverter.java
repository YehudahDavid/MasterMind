import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.Collections;

public class CurrencyConverter extends JFrame{
    //Create ArrayList to hold country abbreviations
    public static ArrayList<String> optionsToChoose = new ArrayList<>();
    public static ArrayList<String> optionsToChoose2 = new ArrayList<>();
    public static void main(String[] args) throws IOException {
        optionsToChoose.add("USD");
        optionsToChoose2.add("USD");
        //Start converter
        createFrame();
    }
    public static void createFrame() throws IOException {
        String sUrl = "http://www.floatrates.com/daily/usd.json";

        try {
            downloadUsingNIO(sUrl, "info.json");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Parser to parse through JSON file (currently only USD)
        JSONParser parser = new JSONParser();
        try {
            //Read in JSON file
            Object obj = parser.parse(new FileReader("info.json"));
            JSONObject jsonObject = (JSONObject)obj;
            for (Object jo : jsonObject.keySet()) {
                optionsToChoose.add(jo.toString().toUpperCase());
                optionsToChoose2.add(jo.toString().toUpperCase());
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        Collections.sort(optionsToChoose);
        Collections.sort(optionsToChoose2);

        String[] opToChoose = new String[optionsToChoose.size()];
        String[] opToChoose2 = new String[optionsToChoose2.size()];

        for (int i = 0; i < optionsToChoose.size(); i++) {
            opToChoose[i] = optionsToChoose.get(i);
        }
        for (int i = 0; i < optionsToChoose2.size(); i++) {
            opToChoose2[i] = optionsToChoose2.get(i);
        }
        JFrame frame = new JFrame("Currency Converter");
        int width = 350, height = 250;
        frame.setSize(width,height);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setIconImage(ImageIO.read(new File("pictures/Dollar-USD-icon.png")));

        JComboBox<String> option1 = new JComboBox<>(opToChoose);
        option1.setBounds(80, 50, 60, 20);

        JComboBox<String> option2 = new JComboBox<>(opToChoose2);
        option2.setBounds(175, 50, 60, 20);

        JButton jButton = new JButton("Convert");
        jButton.setBounds(120,100,90,20);

        JTextPane jTextPane = new JTextPane();
        jTextPane.setBounds(10, 50, 70, 20);

        JLabel jLabel = new JLabel("to");
        jLabel.setBounds(150, 20, 20, 80);

        JLabel converted = new JLabel();
        converted.setBounds(90, 100, 400, 100);

        frame.add(option1);
        frame.add(option2);
        frame.add(jLabel);
        frame.add(converted);
        frame.add(jButton);
        frame.add(jTextPane);

        frame.setLayout(null);
        frame.setVisible(true);

        option1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String country = option1.getItemAt(option1.getSelectedIndex()).toLowerCase();
                System.out.println(country);
                String url = "http://www.floatrates.com/daily/" + country + ".json";

                try {
                    downloadUsingNIO(url, country + ".json");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int amount = Integer.parseInt(jTextPane.getText());
                    double cRate = convert(amount, converted, option1, option2);
                    converted.setText("" + cRate + " " + option2.getItemAt(option2.getSelectedIndex()));
                } catch (NumberFormatException ex) {
                    converted.setText("Not a valid amount");
                }
            }
        });

    }

    public static double convert(int amount, JLabel converted, JComboBox<String> opt1, JComboBox<String> opt2) {
        // Parser to parse through JSON file (currently only USD)
        JSONParser parser = new JSONParser();
        double rate = 0;
        try {
            String country1 = opt1.getItemAt(opt1.getSelectedIndex()).toLowerCase();
            //Read in JSON file
            Object obj = parser.parse(new FileReader(country1 + ".json"));
            JSONObject jsonObject = (JSONObject)obj;
            String country = opt2.getItemAt(opt2.getSelectedIndex()).toLowerCase();
            JSONObject currency = (JSONObject) jsonObject.get(country);
            rate = (double) currency.get("rate");
        } catch(ClassCastException | FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException | ParseException e) {
            throw new RuntimeException(e);
        }

        return (double)amount * rate;
    }

    private static void downloadUsingNIO(String urlStr, String file) throws IOException {
        URL url = new URL(urlStr);
        ReadableByteChannel rbc = Channels.newChannel(url.openStream());
        FileOutputStream fos = new FileOutputStream(file);
        fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
        fos.close();
        rbc.close();
    }

}

