public class CodeSequence {

    int size;
    int[] seq = new int[size];

    public void sequence(int size, int[] seq) {
        setSize(size);
        setSeq(seq);
    }
    public void setSize(int size) {
        this.size = size;
    }

    public int getSize() {
        return size;
    }

    public int[] getSeq() {
        return seq;
    }

    public void setSeq(int[] seq) {
        this.seq = seq;
    }
}
