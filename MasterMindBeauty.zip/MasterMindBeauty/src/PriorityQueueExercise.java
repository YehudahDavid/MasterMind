import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.PriorityQueue;

public class PriorityQueueExercise {
    public static void main(String[] args){
      //call methods
        ArrayList<Integer> arr = new ArrayList<Integer>(Arrays.asList(1,7,3,10,34,5,8));
        System.out.println(kMax(arr, 4));

    }
    
    //specify methods

    public static int kMax(ArrayList<Integer> arr, int k) {
        PriorityQueue<Integer> pq = new PriorityQueue<Integer>(arr.size(), Collections.reverseOrder());

        pq.addAll(arr);

        for (int i = 0; i < pq.size(); i++) {
            int temp = pq.poll();
            if (i == k-1) {
                return temp;
            }
        }

        return 0;
    }
}
